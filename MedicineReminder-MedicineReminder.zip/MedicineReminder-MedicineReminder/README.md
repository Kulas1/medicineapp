# Medicine Reminder with Notifications

<h1> A flutter app with scheduled notifications. to remind the users to take medicines </h1>

![](screenshots/1.png)
![](screenshots/2.png)
![](screenshots/3.png)
![](screenshots/4.png)
