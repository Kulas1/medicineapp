enum DeleteIconState { show, hide }
